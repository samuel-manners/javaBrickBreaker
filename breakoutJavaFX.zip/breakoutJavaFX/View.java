/**
 * <h2>View Class - Displaying the game</h2>
 * This class displays the game onto the screen
 * It also displays the start and end pages
 * Finally, it contains the code required to play music
 */

import javafx.geometry.Insets;
import java.util.ArrayList;
import javafx.event.EventHandler;
import javafx.scene.input.*;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.shape.*;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

// The View class creates and manages the GUI for the application.
// It doesn't know anything about the game itself, it just displays
// the current state of the Model, and handles user input

//audio Imports

import java.io.File;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class View implements EventHandler<KeyEvent>
{ 
    // variables for components of the user interface
    public int width;       // width of window
    public int height;      // height of window

    // usr interface objects
    public Pane pane;       // basic layout pane
    public Canvas canvas;   // canvas to draw game on
    public Label infoText;  // info at top of screen
    public Button startButton; //startButton in the start page
    public Button endButton;   //endButton in the end page

    // The other parts of the model-view-controller setup
    public Controller controller;
    public Model model;
    public Main main;

    public GameObj   bat;            // The bat
    public GameObj   ball;           // The ball
    public ArrayList<GameObj> bricks;     // The bricks
    public int score =  0;     // The score
    
    //sETS GAME MODE POSITION
    public String gamemode = "start";
    

    //Sets the address of the Music we will play
    //Note, you only have to put in directories from the folder of the project
    String bip = "Music/Telephone.mp3";
    //This find the media on the device from the address given
    Media hit = new Media(new File(bip).toURI().toString());
    //This launches the mediaPlayer function to play the music
    MediaPlayer mediaPlayer = new MediaPlayer(hit);
    
    
    // we don't really need a constructor method, but include one to print a 
    // debugging message if required
    public View(int w, int h)
    {
        Debug.trace("View::<constructor>");
        width = w;
        height = h;
    }

    
    /**
     * Button Action Event
     * Changes the display to "game mode"
     * resets the score
     * makes itself invisible
     * activates the music to play
     */
    public void buttonClick(ActionEvent event)
    {
        gamemode = "game";
        score = 0;
        startButton.setVisible(false);
        mediaPlayer.play();
    }
    
    /**
     * Button Action Event
     * Changes the display to the start page
     * makes the end button invisible
     * runs the restart bricks function
     */
    public void endButtonClick(ActionEvent event)
    {
        gamemode = "start";
        endButton.setVisible(false);
        model.restartBricks();
    }
    
    // start is called from Main, to start the GUI up
    // Note that it is important not to create controls etc here and
    // not in the constructor (or as initialisations to instance variables),
    // because we need things to be initialised in the right order
    
    /**
     * <h2>Window Canvas</h2>
     * This sets up a canvas to draw the pages onto
     * Adds all the features to the canvas
     * Says where to go for the code on each button when its clicked
     * Opens the window with the canvas on it
     */
    public void start(Stage window) 
    {
        // breakout is basically one big drawing canvas, and all the objects are
        // drawn on it as rectangles, except for the text at the top - this
        // is a label which sits 'on top of' the canvas.
        
        pane = new Pane();       // a simple layout pane
        pane.setId("Breakout");  // Id to use in CSS file to style the pane if needed
        
        // canvas object - we set the width and height here (from the constructor), 
        // and the pane and window set themselves up to be big enough
        canvas = new Canvas(width,height);  
        pane.getChildren().add(canvas);     // add the canvas to the pane
        
        // infoText box for the score - a label which we position on 
        //the canvas with translations in X and Y coordinates
        infoText = new Label("BreakOut: Score = " + score);
        infoText.setTranslateX(50);
        infoText.setTranslateY(10);
        pane.getChildren().add(infoText);  // add label to the pane
        
        // Button to activate breakout
        startButton = new Button("Start Game");
        startButton.setTranslateX(50);
        startButton.setTranslateY(50);
        pane.getChildren().add(startButton);  // add label to the pane
        
        //End Page Button
        endButton = new Button("Restart");
        endButton.setTranslateX(50);
        endButton.setTranslateY(50);
        pane.getChildren().add(endButton);  // add label to the pane
        endButton.setVisible(false);
        
        //Sets what happens when button is pressed
        startButton.setOnAction(this::buttonClick);
        endButton.setOnAction(this::endButtonClick);

        // add the complete GUI to the scene
        Scene scene = new Scene(pane);   
        scene.getStylesheets().add("breakout.css"); // tell the app to use our css file

        // Add an event handler for key presses. We use the View object itself
        // and provide a handle method to be called when a key is pressed.
        scene.setOnKeyPressed(this);

        // put the scene in the winodw and display it
        window.setScene(scene);
        window.show();
    }
    
    

    // Event handler for key presses - it just passes th event to the controller
    public void handle(KeyEvent event)
    {
        // send the event to the controller
        controller.userKeyInteraction( event );
    }
    
    /**
     * <h2>Deciding the picture</h2>
     * Decides whether the game is displaying the start, game or end page
     * Runs code relevent to draw that picture
     */ 
    public void drawPicture()
    {
        if (gamemode == ("start")){
            drawStartp();
        }
        if (gamemode == ("game")){
        drawGame();
        }
        if (gamemode == ("end")){
         drawEndp();  
         mediaPlayer.stop();
        }
    }
    
    /**
     * <h2>Draw start page</h2>
     * Draws all the features onto the canvas relevent to the start page
     */
    public void drawStartp()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // clear the canvas to redraw
        gc.setFill( Color.GREY );
        gc.fillRect( 0, 0, width, height );
            
        infoText.setText("Welcome to Breakout!");
        startButton.setVisible(true);
        
        //set score to 0
        score = 0;
        model.score = 0;
    }
    
    /**
     * <h2>Draw game page</h2>
     * Draws the game onto the canvas
     */
    public void drawGame()
    {
        // the ball movement is runnng 'i the background' so we have
        // add the following line to make sure
        synchronized( Model.class )   // Make thread safe (because the bal
        {
            
            GraphicsContext gc = canvas.getGraphicsContext2D();

            // clear the canvas to redraw
            gc.setFill( Color.WHITE );
            gc.fillRect( 0, 0, width, height );
            
            // update score
            infoText.setText("BreakOut: Score = " + score);

            // draw the bat and ball
            displayGameObj( gc, ball );   // Display the Ball
            displayGameObj( gc, bat  );   // Display the Bat

            // *[3]****************************************************[3]*
            // * Display the bricks that make up the game                 *
            // * Fill in code to display bricks from the ArrayList        *
            // * Remember only a visible brick is to be displayed         *
            // ************************************************************
            for (GameObj brick:bricks){
                if (brick.visible){
                displayGameObj( gc, brick ); 
            }
            
            if (model.bricks_left == 0){
               gamemode = "end"; 
            }
        }
        }
    }

    /**
     * <h2>Draw end page</h2>
     * Draws all the features onto the canvas relevent to the end page
     */
    public void drawEndp()
    {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        
        // clear the canvas to redraw
        gc.setFill( Color.GREY );
        gc.fillRect( 0, 0, width, height );
        
        //add the end text and end button to the screen   
        infoText.setText("You Scored " + score + " points!");
        endButton.setVisible(true);
    }
    
    // Display a game object - it is just a rectangle on the canvas
    public void displayGameObj( GraphicsContext gc, GameObj go )
    {
        gc.setFill( go.colour );
        gc.fillRect( go.topX, go.topY, go.width, go.height );
    }

    // This is how the Model talks to the View
    // This method gets called BY THE MODEL, whenever the model changes
    // It has to do whatever is required to update the GUI to show the new model status
    public void update()
    {
        // Get from the model the ball, bat, bricks & score
        ball    = model.getBall();              // Ball
        bricks  = model.getBricks();            // Bricks
        bat     = model.getBat();               // Bat
        score   = model.getScore();             // Score
        //Debug.trace("Update");
        drawPicture();                     // Re draw game
    }
}
